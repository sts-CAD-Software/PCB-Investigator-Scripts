﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadanceNetGroup2PCBI
{
    static class Program
    {
        internal static string StartUpJobToLoad = "";
        internal static string StartUpStepToLoad = "pcb";
        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                // defenitions: -all alle layer öffnen -L LayerName 
                // fagov c:/jobs/74100 -step panel
                args[0] = args[0].Replace("/", "\\");
                StartUpJobToLoad = args[0];

                for (int loop = 0; loop < args.Length; loop++)
                {
                    if (args[loop].StartsWith("-step"))
                        StartUpStepToLoad = args[loop + 1];
                }
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
