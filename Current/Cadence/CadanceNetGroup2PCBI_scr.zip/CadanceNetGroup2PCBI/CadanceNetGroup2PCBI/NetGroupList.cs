﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Collections;
using System.Windows.Forms;

namespace CadanceNetGroup2PCBI
{
    [Serializable()]
    [XmlRoot("GroupList")]
    public class NetGroupList
    {
        public List<NetGroup> GroupList;

        public NetGroupList()
        {
            GroupList = new List<NetGroup>();
        }

        public NetGroup GetGroupByName(string name, string groupStepName)
        {
            foreach (NetGroup List in GroupList)
            {
                if (List.GroupName == name && List.stepName == groupStepName)
                {
                    return List;
                }
            }
            return null;
        }

        public void SaveList(string FullName)
        {
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(FullName)))
                    Directory.CreateDirectory(Path.GetDirectoryName(FullName));

                if (File.Exists(FullName))
                    File.Delete(FullName);

                XmlSerializer mySerializer = new XmlSerializer(typeof(NetGroupList));
                FileStream myFileStream = new FileStream(FullName, FileMode.Create, FileAccess.ReadWrite);
                mySerializer.Serialize(myFileStream, this);
                myFileStream.Close();
            }
            catch (Exception ext)
            {
                MessageBox.Show(ext.ToString(), "error");
                Console.WriteLine("Error: " + ext.ToString());
            }
        }
        //never used...
        public NetGroupList LoadList(string FullName)
        {
            XmlSerializer mySerializer = new XmlSerializer(typeof(NetGroupList));
            FileStream myFileStream = new FileStream(FullName, FileMode.Open, FileAccess.Read);
            NetGroupList resList = (NetGroupList)mySerializer.Deserialize(myFileStream);

            myFileStream.Close();
            return resList;
        }

    }
}
