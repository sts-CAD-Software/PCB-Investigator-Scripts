﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;



namespace CadanceNetGroup2PCBI
{
    [Serializable()]
    [XmlRoot("NetGroup")]
    public class NetGroup
    {
        public NetGroup()
        {
            
            NetList = new List<string>();
        }
        public List<string> NetList;
        public string GroupName = "";
        public string Description = "";
        public string stepName = "";

        public int Color = 0;
        internal int indexOfImageInGroupList = 0;

        public void AddGroupName(string groupName)
        {
            GroupName = groupName;
        }
        public int countNets()
        {
            return NetList.Count();
        }

        public void AddNet(string NetName)
        {
            NetList.Add(NetName);
        }

        public void AddNetGroup(string groupName, List<string> NameList)
        {
            GroupName = groupName;
            NetList = NameList;
        }
    }
}
