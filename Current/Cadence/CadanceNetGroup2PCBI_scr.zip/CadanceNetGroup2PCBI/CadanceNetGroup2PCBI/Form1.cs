﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadanceNetGroup2PCBI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            if (Program.StartUpStepToLoad.Length > 0)
                textBoxStepName.Text = Program.StartUpStepToLoad;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "dcf | *.dcf";
            openFileDialog1.FileName = "";
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Read(openFileDialog1.FileName);
            }
        }
        private List<string> parts(string list)
        {
            List<string> sb = new List<string>();
            char[] splitter = new char[2];
            splitter[0] = '(';
            splitter[1] = ')';
            string[] slist = list.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
            return slist.ToList();
        }
         private string FindBetweenParentheses(string Text)
        {
            string ret = "";
            bool start = false;
            foreach (char c in Text)
            {
                if (start && c == '"') break;
                if (start)
                {
                    ret = ret + c;
                }
                if (c == '"')
                    start = true;
            }
            return ret;
        }
        private NetGroupList netGroupList;
        private void Read(string Fullname)
        {
            string data = File.ReadAllText(Fullname); //read File 

            List<string> dataitem = parts(data);
            NetGroup netGroup = new NetGroup();
            netGroupList = new NetGroupList();
            bool first = true;
            foreach (string netclass in dataitem)
            {
              string  netclassT =netclass.Trim().TrimEnd(new char[] { '\r', '\n' }); ;

                if (netclassT.Length == 0) continue;
                if(netclassT.Contains("netClass") || netclassT.Contains("bus"))
                {
                    if (!first && netGroup.NetList.Count > 0) netGroupList.GroupList.Add(netGroup);
                    first = false;
                    netGroup = new NetGroup();
                    netGroup.stepName = textBoxStepName.Text;
                    netGroup.GroupName = FindBetweenParentheses(netclassT);
                    netGroup.Description = netclassT;
                }
                if (netclassT.Contains("signalRef"))
                {
                    netGroup.AddNet(FindBetweenParentheses(netclassT));
                }
            }
            if(netGroup.NetList.Count > 0)
            netGroupList.GroupList.Add(netGroup);

            labelFound.Text = "Groups in File " + netGroupList.GroupList.Count.ToString();
            if (netGroupList.GroupList.Count > 0) button2.Enabled = true;

            if(Program.StartUpJobToLoad.Length > 0)
            {
                string dir = Program.StartUpJobToLoad + @"\user\";
                if(!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                string fullname = Program.StartUpJobToLoad + @"\user\PCBI_Net_Group_List.xml";
                saveFileDialog1.FileName = fullname;
                netGroupList.SaveList(fullname);
                MessageBox.Show("Please open Net Group in PCBI ", "Cadence Import", MessageBoxButtons.OK);
                this.Close();
            }

        }
        private void buttonSave_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "xml | *.xml";
          //  saveFileDialog1.FileName = "PCBI_Net_Group_List";
            if (  saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                netGroupList.SaveList(saveFileDialog1.FileName);
            }
        }
    }
}
